-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2017 at 09:51 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dealer-soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `comp_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `corp_country` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'India',
  `corp_state` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `corp_district` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `corp_city` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `corp_office` tinytext COLLATE latin1_general_ci NOT NULL,
  `corp_address` tinytext COLLATE latin1_general_ci NOT NULL,
  `corp_phone` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `corp_email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `corp_website` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `primary_contact` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `primary_phone` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `primary_mobile` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `primary_email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `primary_fax` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `primary_country` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `primary_district` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `state` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_address` tinytext COLLATE latin1_general_ci NOT NULL,
  `shipping_address` text COLLATE latin1_general_ci NOT NULL,
  `plant_phone` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `plant_conperson` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `plant_fax` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_country` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `plant_state` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `plant_district` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `plant_city` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `tin_num` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `handling_person` int(11) NOT NULL,
  `client_type` enum('Client','Lead') COLLATE latin1_general_ci NOT NULL DEFAULT 'Client',
  `status` enum('Active','In-Active') COLLATE latin1_general_ci NOT NULL DEFAULT 'Active',
  `vat_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `gstin_num` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `cst_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `excise_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `pan_no` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `notes` text COLLATE latin1_general_ci NOT NULL,
  `other_information` text COLLATE latin1_general_ci NOT NULL,
  `credit_limit` float(10,2) NOT NULL,
  `client_source` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `client_potential` float(10,2) NOT NULL,
  `client_rating` int(1) NOT NULL,
  `product_rating` int(1) NOT NULL,
  `client_rating_reason` text COLLATE latin1_general_ci NOT NULL,
  `product_rating_reason` text COLLATE latin1_general_ci NOT NULL,
  `interested_crops` text COLLATE latin1_general_ci NOT NULL,
  `work_area` text COLLATE latin1_general_ci NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  `account_number` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `account_name` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `bank_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `bank_branch` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `ifsc_code` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL COMMENT 'Client''s date of Birth',
  PRIMARY KEY (`comp_id`),
  KEY `tin_num` (`tin_num`),
  KEY `handling_person` (`handling_person`),
  KEY `updated_by` (`updated_by`),
  KEY `client_type` (`client_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1504 ;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`comp_id`, `comp_name`, `corp_country`, `corp_state`, `corp_district`, `corp_city`, `corp_office`, `corp_address`, `corp_phone`, `corp_email`, `corp_website`, `primary_contact`, `primary_phone`, `primary_mobile`, `primary_email`, `primary_fax`, `primary_country`, `primary_district`, `state`, `city`, `plant_address`, `shipping_address`, `plant_phone`, `plant_email`, `plant_conperson`, `plant_fax`, `plant_country`, `plant_state`, `plant_district`, `plant_city`, `tin_num`, `handling_person`, `client_type`, `status`, `vat_no`, `gstin_num`, `cst_no`, `excise_no`, `pan_no`, `notes`, `other_information`, `credit_limit`, `client_source`, `client_potential`, `client_rating`, `product_rating`, `client_rating_reason`, `product_rating_reason`, `interested_crops`, `work_area`, `updated_by`, `updated_date`, `account_number`, `account_name`, `bank_name`, `bank_branch`, `ifsc_code`, `dob`) VALUES
(1503, 'Client -1', 'India', '', '', '', '', '', '', '', '', 'Contact Name -1', '0253-414011', '1234567890', 'contactemail-1@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '1234567GST', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-06-14', '', '', '', '', '', '0000-00-00'),
(1501, 'Client -2 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -2', '94216021762', '2', 'contactemail-2@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1502, 'Client -3 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -3', '0253-66041103', '98224205353', 'contactemail-3@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1500, 'Client -4 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -4', '99224244924', '4', 'contactemail-4@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1497, 'Client -5 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -5', '98904450125', '5', 'contactemail-5@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1498, 'Client -6 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -6', '0253-23518546', '98501659576', 'contactemail-6@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1499, 'Client -7 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -7', '98225029987', '7', 'contactemail-7@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1495, 'Client -8 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -8', '0253-32917958', '98232492328', 'contactemail-8@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1496, 'Client -9 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -9', '95525601159', '9', 'contactemail-9@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '27190001153 V', '', '27190001153 C', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1492, 'Client -10 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -10', '952719180910', '10', 'contactemail-10@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1493, 'Client -11', 'India', '', '', '', '', '', '', '', '', 'Contact Name -11', '982217868111', '11', 'contactemail-11@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '27150311493 GST', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-06-14', '', '', '', '', '', '0000-00-00'),
(1494, 'Client -12 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -12', '0253-238496512', '992250817212', 'contactemail-12@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1490, 'Client -13 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -13', '0253-238573013', '942274830013', 'contactemail-13@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1491, 'Client -14 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -14', '982291189514', '982291189514', 'contactemail-14@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1488, 'Client -15 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -15', '0253-238649415', '738598318715', 'contactemail-15@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1489, 'Client -16 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -16', '0253-657836316', '962384807016', 'contactemail-16@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1485, 'Client -17 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -17', '0253-238236717', '982277099317', 'contactemail-17@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1486, 'Client -18 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -18', '0253-238375818', '985084672918', 'contactemail-18@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1487, 'Client -19 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -19', '952757733119', '19', 'contactemail-19@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1483, 'Client -20 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -20', '860002299520', '20', 'contactemail-20@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1484, 'Client -21 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -21', '0253-238329421', '982255839421', 'contactemail-21@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1481, 'Client -22 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -22', '0253-661226622', '22', 'contactemail-22@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1482, 'Client -23 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -23', '955269957423', '942226257623', 'contactemail-23@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1478, 'Client -24 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -24', '942226130324', '24', 'contactemail-24@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1479, 'Client -25 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -25', '942226130325', '25', 'contactemail-25@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1480, 'Client -26 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -26', '0253-664938326', '913002289126', 'contactemail-26@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1476, 'Client -27 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -27', '0253-238464627', '985056139927', 'contactemail-27@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1477, 'Client -28 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -28', '0253-240878228', '28', 'contactemail-28@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1473, 'Client -29 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -29', '992205099929', '901140218129', 'contactemail-29@gmail.com', '', '', '', '', 'Nasik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1474, 'Client -30 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -30', '922513350230', '922513350230', 'contactemail-30@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1475, 'Client -31 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -31', '0253-661820531', '0253-661820431', 'contactemail-31@gmail.com', '', '', '', '', 'Nasik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1471, 'Client -32 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -32', '0253 660298032', '830811657532', 'contactemail-32@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '27180663232 V', '', '27180663232 C', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1472, 'Client -33 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -33', '0253-235330033', '33', 'contactemail-33@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1467, 'Client -34 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -34', '967358033234', '967358033234', 'contactemail-34@gmail.com', '', '', '', '', 'Satana', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1468, 'Client -35 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -35', '0253-660775235', '942266209935', 'contactemail-35@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '27730363151', 0, 'Client', 'Active', '27730363151 V', '', '27730363151 C', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1469, 'Client -36 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -36', '0253-238365436', '992244445436', 'contactemail-36@gmail.com', '', '', '', '', 'Nasik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '27130580664 V', '', '27130580664 C', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1470, 'Client -37 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -37', '942396393437', '942396393537', 'contactemail-37@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1465, 'Client -38 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -38', '0253-238337238', '988109709838', 'contactemail-38@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1466, 'Client -39 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -39', '0253-238337239', '988109709839', 'contactemail-39@gmail.com', '', '', '', '', 'Nasik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1462, 'Client -40 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -40', '982315409040', '982315409040', 'contactemail-40@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1463, 'Client -41 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -41', '942275058741', '942275058741', 'contactemail-41@gmail.com', '', '', '', '', '', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1464, 'Client -42 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -42', '985012365742', '879302365742', 'contactemail-42@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1458, 'Client -43 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -43', '0253-662189743', '988109709843', 'contactemail-43@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '27630038644V', '', '27630038644C', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-21', '', '', '', '', '', '0000-00-00'),
(1459, 'Client -44 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -44', '976225988644', '976225988544', 'contactemail-44@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-21', '', '', '', '', '', '0000-00-00'),
(1461, 'Client -45 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -45', '0253-238320845', '932406587745', 'contactemail-45@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '', '', '', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-30', '', '', '', '', '', '0000-00-00'),
(1460, 'Client -46 ', 'India', '', '', '', '', '', '', '', '', 'Contact Name -46', '0253- 24088346', '986030436646', 'contactemail-46@gmail.com', '', '', '', '', 'Nashik', '', 'Address will be here', '', '', '', '', '', '', '', '', '', 0, 'Client', 'Active', '27320003846V', '', '27320003846V', '', '', '', '', 0.00, '', 0.00, 0, 0, '', '', '', '', 1, '2017-03-27', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `client_orders`
--

CREATE TABLE IF NOT EXISTS `client_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(15) NOT NULL,
  `challan_number` varchar(30) NOT NULL,
  `invoice_number` varchar(30) NOT NULL,
  `invoice_firm` int(11) NOT NULL DEFAULT '1' COMMENT 'order under firm',
  `comp_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `shipping_address` text NOT NULL,
  `billing_address` text NOT NULL,
  `state_code` int(2) NOT NULL DEFAULT '27',
  `discount` float(6,2) NOT NULL DEFAULT '0.00',
  `order_date` date NOT NULL,
  `order_status` varchar(9) NOT NULL DEFAULT 'Pending' COMMENT 'Pending, Completed and Closed',
  `payment_reminder` date NOT NULL DEFAULT '0000-00-00',
  `forwardingAmt` float(10,2) NOT NULL DEFAULT '0.00',
  `order_type` enum('Tax','Labour') NOT NULL DEFAULT 'Labour',
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`order_id`,`comp_id`,`uid`),
  KEY `invoice_number` (`invoice_firm`),
  KEY `invoice_firm` (`invoice_firm`),
  KEY `comp_id` (`comp_id`),
  KEY `uid` (`uid`),
  KEY `order_status` (`order_status`),
  KEY `order_number` (`order_number`),
  KEY `order_type` (`order_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `client_orders`
--

INSERT INTO `client_orders` (`order_id`, `order_number`, `challan_number`, `invoice_number`, `invoice_firm`, `comp_id`, `uid`, `contact_person`, `shipping_address`, `billing_address`, `state_code`, `discount`, `order_date`, `order_status`, `payment_reminder`, `forwardingAmt`, `order_type`, `updated_by`, `updated_date`) VALUES
(7, 'JMDE/16-17/27', 'JMDE/16-17/DC/557', 'JMDE/16-17/IN/517', 1, 1494, 1, 'Contact Name -12', 'Address will be here 0\r\nAddress will be here 1\r\nAddress will be here 2', 'Address will be here\r\nAddress will be here\r\nAddress will be here', 27, 0.00, '2017-06-14', 'Completed', '2017-07-27', 0.00, 'Tax', 1, '2017-06-14'),
(9, 'JE/16-17/28', 'JE/16-17/DC/558', 'JE/16-17/IN/518', 1, 1493, 1, 'Contact Name -11', 'Address will be here', 'Address will be here', 27, 0.00, '2017-06-15', 'Completed', '0000-00-00', 0.00, 'Tax', 1, '2017-06-15'),
(12, 'JE/16-17/30', 'JE/16-17/DC/560', 'JE/16-17/IN/520', 1, 1490, 1, 'Contact Name -13', 'Address will be here', 'Address will be here', 27, 0.00, '2017-06-15', 'Completed', '2017-08-04', 0.00, 'Tax', 1, '2017-06-15'),
(11, 'JE/16-17/29', 'JE/16-17/DC/559', 'JE/16-17/IN/519', 1, 1491, 1, 'Contact Name -14', 'Address will be here\r\nAddress will be here\r\nCity Name\r\nState - 422001', 'Address will be here\r\nAddress will be here\r\nCity Name\r\nState - 422001', 27, 0.00, '2017-06-15', 'Completed', '0000-00-00', 300.00, 'Tax', 1, '2017-06-15'),
(5, 'JMDE/16-17/25', 'JMDE/16-17/DC/555', 'JMDE/16-17/IN/515', 1, 1493, 1, 'Contact Name -11', 'Shipping  Address will be here 1\r\nShipping  Address will be here 2\r\nShipping  Address will be here 3', 'Address will be here 1\r\nAddress will be here 2\r\nAddress will be here 3', 27, 0.00, '2017-06-11', 'Completed', '2017-06-12', 300.00, 'Tax', 1, '2017-06-11'),
(6, 'JMDE/16-17/26', 'JMDE/16-17/DC/556', 'JMDE/16-17/IN/516', 1, 1493, 1, 'Contact Name -11', 'Address will be here', 'Address will be here', 27, 0.00, '2017-06-12', 'Completed', '0000-00-00', 0.00, 'Tax', 1, '2017-06-12'),
(13, 'JE/16-17/31', 'JE/16-17/D/561', 'JE/16-17/I/521', 1, 1492, 1, 'Shahu Sawant', 'Address will be here\r\nAddress line 2 \r\nNashik-10', 'Address will be here\r\nAddress line 2 \r\nNashik-10', 27, 0.00, '2017-06-21', 'Completed', '0000-00-00', 0.00, 'Tax', 1, '2017-06-21'),
(14, 'JE/16-17/32', 'JE/16-17/D/562', 'JE/16-17/I/522', 1, 1503, 1, 'Nikhil Ahire', 'Address will be here', 'Address will be here', 29, 0.00, '2017-06-21', 'Pending', '2017-06-30', 0.00, 'Tax', 1, '2017-06-21'),
(15, 'JE/17-18/33', 'JE/17-18/D/563', 'JE/17-18/I/523', 1, 1503, 1, 'प्रवीण सावंत', 'Address will be here\r\nAddress will be here\r\nAddress will be here', 'Address will be here\r\nAddress will be here\r\nAddress will be here', 27, 0.00, '2017-06-21', 'Pending', '0000-00-00', 0.00, 'Tax', 1, '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `client_order_prodcts`
--

CREATE TABLE IF NOT EXISTS `client_order_prodcts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This will be used in challen table as ref_id',
  `order_id` int(11) NOT NULL,
  `order_pid` int(11) NOT NULL DEFAULT '0',
  `prod_ref_name` varchar(256) NOT NULL,
  `order_qty` float(10,2) NOT NULL,
  `order_rate` float(10,2) NOT NULL,
  `tax_free` enum('Yes','No') NOT NULL DEFAULT 'No',
  `sgst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `cgst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `igst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `part_no` varchar(150) NOT NULL,
  `remark` varchar(256) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `client_order_prodcts`
--

INSERT INTO `client_order_prodcts` (`id`, `order_id`, `order_pid`, `prod_ref_name`, `order_qty`, `order_rate`, `tax_free`, `sgst_per`, `cgst_per`, `igst_per`, `part_no`, `remark`, `updated_by`, `updated_date`) VALUES
(21, 13, 32, 'Produt Name -32', 2.00, 1100.00, 'No', 9.00, 9.00, 0.00, '', '', 1, '2017-06-21'),
(8, 6, 32, 'Produt Name -32', 500.00, 100.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-12'),
(9, 6, 127, 'Produt Name -127', 50.00, 200.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-12'),
(10, 7, 33, 'Produt Name -33', 7.00, 200.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-14'),
(12, 9, 33, 'Produt Name -33', 100.00, 105.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(13, 9, 51, 'Produt Name -51', 50.00, 450.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(18, 11, 51, 'Produt Name -51', 20.00, 255.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(17, 11, 33, 'Produt Name -33', 10.00, 250.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(19, 12, 33, 'Produt Name -33', 100.00, 20.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(20, 12, 51, 'Produt Name -51', 50.00, 300.00, 'No', 0.00, 0.00, 0.00, '', '', 1, '2017-06-15'),
(22, 13, 94, 'Produt Name -94', 1.00, 1200.00, 'No', 9.00, 9.00, 0.00, '', '', 1, '2017-06-21'),
(23, 14, 33, 'Produt Name -33', 5.00, 1200.00, 'No', 0.00, 0.00, 18.00, '', '', 1, '2017-06-21'),
(24, 14, 51, 'Produt Name -51', 2.00, 1000.00, 'No', 0.00, 0.00, 18.00, '', '', 1, '2017-06-21'),
(25, 15, 32, 'Produt Name -32', 10.00, 500.00, 'No', 9.00, 9.00, 0.00, '', '', 1, '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `company_firms`
--

CREATE TABLE IF NOT EXISTS `company_firms` (
  `firm_id` int(11) NOT NULL AUTO_INCREMENT,
  `firm_name` varchar(100) NOT NULL,
  `firm_code` varchar(5) NOT NULL,
  `current_year` varchar(7) NOT NULL,
  `current_challan` int(11) NOT NULL,
  `current_invoice` int(11) NOT NULL,
  `lot_no` int(11) NOT NULL DEFAULT '0',
  `material_inward_no` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL,
  `po_number` int(11) NOT NULL DEFAULT '0',
  `vat_num` varchar(20) NOT NULL,
  `cst_num` varchar(20) NOT NULL,
  `excise_num` varchar(40) NOT NULL,
  `gst_num` varchar(11) NOT NULL,
  `state_code` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','In-Active') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`firm_id`),
  KEY `current_excise` (`gst_num`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `company_firms`
--

INSERT INTO `company_firms` (`firm_id`, `firm_name`, `firm_code`, `current_year`, `current_challan`, `current_invoice`, `lot_no`, `material_inward_no`, `order_id`, `po_number`, `vat_num`, `cst_num`, `excise_num`, `gst_num`, `state_code`, `status`) VALUES
(1, 'Your Firm Name', 'JE', '17-18', 563, 523, 7, 7, 33, 2, '27270602606 V', '27270602606 C', '', '27270601GST', 27, 'Active'),
(2, 'Firm Two', 'JG', '17-18', 42, 42, 0, 0, 9, 0, '', '', '', '27270602GST', 27, 'In-Active');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `emp_id` int(4) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(50) NOT NULL,
  `emp_mobile` varchar(25) NOT NULL,
  `emp_address` text NOT NULL,
  `emp_status` enum('Active','In-Active') NOT NULL DEFAULT 'Active',
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `emp_mobile`, `emp_address`, `emp_status`, `updated_by`, `updated_date`) VALUES
(1, 'Ajay Khandagale', '12346579258', '', 'Active', 1, '2017-03-30'),
(2, 'Suresh Varma', '12332131112', '', 'In-Active', 1, '2017-03-30'),
(3, 'Devidas More', '123564564', '', 'Active', 1, '2017-03-30'),
(4, 'Dayashankar Varma', '1231311321', '', 'Active', 1, '2017-03-30'),
(5, 'Amanat Yadav', '45664644', '', 'Active', 1, '2017-03-30');

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance`
--

CREATE TABLE IF NOT EXISTS `employee_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `in_time` time NOT NULL,
  `out_time` time NOT NULL,
  `atn_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_id` (`emp_id`,`atn_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `employee_attendance`
--

INSERT INTO `employee_attendance` (`id`, `emp_id`, `in_time`, `out_time`, `atn_date`) VALUES
(1, 3, '08:00:00', '12:00:00', '2017-03-31'),
(2, 4, '00:00:00', '20:00:00', '2017-03-31'),
(6, 3, '00:00:00', '20:00:00', '2017-04-01'),
(7, 4, '07:15:00', '20:00:00', '2017-04-01'),
(8, 5, '07:30:00', '20:20:00', '2017-04-01'),
(9, 1, '08:00:00', '20:20:00', '2017-04-01'),
(10, 3, '08:30:00', '16:55:00', '2017-04-17'),
(11, 4, '08:30:00', '16:55:00', '2017-04-17'),
(12, 5, '08:30:00', '16:55:00', '2017-04-17'),
(13, 1, '08:30:00', '16:55:00', '2017-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `gst_state_codes`
--

CREATE TABLE IF NOT EXISTS `gst_state_codes` (
  `state_id` int(3) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(100) NOT NULL,
  `state_code` int(3) NOT NULL,
  PRIMARY KEY (`state_id`),
  KEY `state_name` (`state_name`,`state_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `gst_state_codes`
--

INSERT INTO `gst_state_codes` (`state_id`, `state_name`, `state_code`) VALUES
(35, 'Andaman and Nicobar Islands', 35),
(28, 'Andhra Pradesh', 28),
(12, 'Arunachal Pradesh', 12),
(18, 'Assam', 18),
(10, 'Bihar', 10),
(4, 'Chandigarh', 4),
(22, 'Chhattisgarh', 22),
(26, 'Dadra and Nagar Haveli', 26),
(25, 'Daman and Diu', 25),
(7, 'Delhi', 7),
(30, 'Goa', 30),
(24, 'Gujarat', 24),
(6, 'Haryana', 6),
(2, 'Himachal Pradesh', 2),
(1, 'Jammu and Kashmir', 1),
(20, 'Jharkhand', 20),
(29, 'Karnataka', 29),
(32, 'Kerala', 32),
(31, 'Lakshadweep', 31),
(23, 'Madhya Pradesh', 23),
(27, 'Maharashtra', 27),
(14, 'Manipur', 14),
(17, 'Meghalaya', 17),
(15, 'Mizoram', 15),
(13, 'Nagaland', 13),
(21, 'Orissa', 21),
(34, 'Puducherry', 34),
(3, 'Punjab', 3),
(8, 'Rajasthan', 8),
(11, 'Sikkim', 11),
(33, 'Tamil Nadu', 33),
(16, 'Tripura', 16),
(9, 'Uttar Pradesh', 9),
(5, 'Uttarakhand', 5),
(19, 'West Bengal', 19);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_payments`
--

CREATE TABLE IF NOT EXISTS `invoice_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `client_id` int(11) NOT NULL,
  `invoice_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `paid_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `firm_id` int(3) NOT NULL,
  `order_by` int(11) NOT NULL,
  `status` enum('Pending','Paid') NOT NULL DEFAULT 'Pending',
  `reminder_date` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `client_id` (`client_id`,`status`,`reminder_date`),
  KEY `firm_id` (`firm_id`),
  KEY `order_id` (`updated_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `invoice_payments`
--

INSERT INTO `invoice_payments` (`payment_id`, `invoice_number`, `client_id`, `invoice_amount`, `paid_amount`, `firm_id`, `order_by`, `status`, `reminder_date`, `updated_by`, `updated_date`) VALUES
(9, 'JE/16-17/IN/519', 1491, 9268.00, 0.00, 1, 1, 'Pending', '0000-00-00', 1, '2017-06-15'),
(8, 'JE/16-17/IN/518', 1493, 38940.00, 0.00, 1, 1, 'Pending', '0000-00-00', 1, '2017-06-15'),
(7, 'JMDE/16-17/IN/517', 1494, 1652.00, 0.00, 1, 1, 'Pending', '2017-07-27', 1, '2017-06-14'),
(5, 'JMDE/16-17/IN/515', 1493, 47500.00, 0.00, 1, 1, 'Pending', '2017-06-12', 1, '2017-06-11'),
(6, 'JMDE/16-17/IN/516', 1493, 76800.00, 0.00, 1, 1, 'Pending', '0000-00-00', 1, '2017-06-12'),
(10, 'JE/16-17/IN/520', 1490, 20060.00, 15000.00, 1, 1, 'Pending', '2017-08-04', 1, '2017-06-15'),
(11, 'JE/16-17/I/521', 1492, 3340.00, 3300.00, 1, 1, 'Pending', '0000-00-00', 1, '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(3) NOT NULL,
  `message_text` text NOT NULL,
  `added_on` date NOT NULL,
  `reminder_date` datetime NOT NULL,
  `read_flag` enum('Pending','Read') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`reminder_date`,`read_flag`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `uid`, `message_text`, `added_on`, `reminder_date`, `read_flag`) VALUES
(1, 1, 'Your payment is due on 2017-06-12 for invoice # JMDE/16-17/IN/515 from Client -11 ', '2017-06-11', '2017-06-12 00:00:00', 'Pending'),
(2, 1, 'Your payment is due on 2017-07-27 for invoice # JMDE/16-17/IN/517 from Client -12 ', '2017-06-14', '2017-07-27 00:00:00', 'Pending'),
(3, 1, 'Your payment is due on 2017-08-04 for invoice # JE/16-17/IN/520 from Client -13 ', '2017-06-15', '2017-08-04 00:00:00', 'Pending'),
(4, 1, 'Take follow-up of PO # JE/PO/16-17/1 for receiving material.', '2017-06-17', '0000-00-00 00:00:00', 'Read'),
(5, 1, 'Take follow-up of PO # JE/PO/16-17/2 for receiving material.', '2017-06-20', '0000-00-00 00:00:00', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE IF NOT EXISTS `payment_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_ref_id` int(11) NOT NULL DEFAULT '0' COMMENT 'client_id, Supl_id. For account heads = 0',
  `payment_ref_type` int(11) NOT NULL DEFAULT '0' COMMENT 'account_heads->head_id',
  `debit_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `credit_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `bank_id` int(11) NOT NULL DEFAULT '0',
  `firm_id` int(11) NOT NULL DEFAULT '0',
  `transaction_id` varchar(25) NOT NULL,
  `transaction_date` date NOT NULL DEFAULT '0000-00-00',
  `transaction_title` varchar(256) NOT NULL,
  `payment_by` varchar(30) NOT NULL,
  `payment_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Primary key of invoice_payment or purchase_order_payments',
  `notes` text NOT NULL,
  `updated_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_ref_id`,`bank_id`,`transaction_date`),
  KEY `purc_payment_id` (`payment_ref_type`),
  KEY `firm_id` (`firm_id`),
  KEY `payment_id_2` (`payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`id`, `payment_ref_id`, `payment_ref_type`, `debit_amount`, `credit_amount`, `bank_id`, `firm_id`, `transaction_id`, `transaction_date`, `transaction_title`, `payment_by`, `payment_id`, `notes`, `updated_by`) VALUES
(5, 1493, 1, 47500.00, 0.00, 0, 1, '', '2017-06-11', 'Payment of Invoice #JMDE/16-17/IN/515', '', 5, '', 1),
(6, 1493, 1, 76800.00, 0.00, 0, 1, '', '2017-06-12', 'Payment of Invoice #JMDE/16-17/IN/516', '', 6, '', 1),
(7, 1494, 1, 1652.00, 0.00, 0, 1, '', '2017-06-14', 'Payment of Invoice #JMDE/16-17/IN/517', '', 7, '', 1),
(8, 1493, 1, 38940.00, 0.00, 0, 1, '', '2017-06-15', 'Payment of Invoice #JE/16-17/IN/518', '', 8, '', 1),
(9, 481, 2, 22273.00, 0.00, 0, 1, 'Invoice/17-18/2', '2017-06-15', 'Invoice number Invoice/17-18/2', '', 0, 'Invoice number Invoice/17-18/2', 1),
(10, 1491, 1, 9268.00, 0.00, 0, 1, '', '2017-06-15', 'Payment of Invoice #JE/16-17/IN/519', '', 9, '', 1),
(11, 1490, 1, 20060.00, 0.00, 0, 1, '', '2017-06-15', 'Payment of Invoice #JE/16-17/IN/520', '', 10, '', 1),
(12, 1490, 1, 0.00, 15000.00, 0, 1, 'txn-12345678', '2017-06-15', 'Transaction Title here', 'Bank Deposit', 0, 'Payment Note', 1),
(13, 1492, 1, 3340.00, 0.00, 0, 1, '', '2017-06-21', 'Payment of Invoice #JE/16-17/I/521', '', 11, '', 1),
(14, 1492, 1, 0.00, 3300.00, 0, 1, 'JE/16-17/I/521', '2017-06-21', 'Payment of JE/16-17/I/521', 'Cash', 0, 'Payment Note', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_desc` text NOT NULL,
  `prod_unit` varchar(3) NOT NULL DEFAULT 'Kg',
  `min_qty` float(7,2) NOT NULL DEFAULT '0.00',
  `hsn_code` varchar(50) NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `sub_category` varchar(100) NOT NULL,
  `sgst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `cgst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `igst_per` float(4,2) NOT NULL DEFAULT '0.00',
  `selling_price` float(10,2) NOT NULL DEFAULT '0.00',
  `tax_free` enum('Yes','No') NOT NULL DEFAULT 'No',
  `updated_by` int(11) NOT NULL COMMENT 'users->uid',
  `updated_date` date NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `item_code` (`product_brand`,`product_name`),
  KEY `min_qty` (`min_qty`),
  KEY `sgst_per` (`sgst_per`,`cgst_per`,`igst_per`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=435 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `item_code`, `product_brand`, `product_name`, `product_desc`, `prod_unit`, `min_qty`, `hsn_code`, `product_category`, `sub_category`, `sgst_per`, `cgst_per`, `igst_per`, `selling_price`, `tax_free`, `updated_by`, `updated_date`) VALUES
(1, 'AG/SO/011', '', 'Produt Name -1', 'product Desc will be here for produt name -1', 'Lit', 0.00, '', 'Agro Chemical', 'Solvent', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(2, 'AG/PA/012', '', 'Produt Name -2', 'product Desc will be here for produt name -2', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(3, 'AH/013', '', 'Produt Name -3', 'product Desc will be here for produt name -3', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(4, 'AG/EM/014', '', 'Produt Name -4', 'product Desc will be here for produt name -4', 'Kg', 0.00, '', 'Agro Chemical', 'Emulsifier', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(5, 'MF/AM/015', '', 'Produt Name -5', 'product Desc will be here for produt name -5', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(6, 'MF/AM/026', '', 'Produt Name -6', 'product Desc will be here for produt name -6', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(7, 'MF/AM/037', '', 'Produt Name -7', 'product Desc will be here for produt name -7', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(8, 'MF/AM/048', '', 'Produt Name -8', 'product Desc will be here for produt name -8', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(9, 'MF/AM/059', '', 'Produt Name -9', 'product Desc will be here for produt name -9', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(10, 'MF/AM/0610', '', 'Produt Name -10', 'product Desc will be here for produt name -10', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(11, 'MF/AM/0711', '', 'Produt Name -11', 'product Desc will be here for produt name -11', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(12, 'MF/AM/0812', '', 'Produt Name -12', 'product Desc will be here for produt name -12', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(13, 'MF/AM/0913', '', 'Produt Name -13', 'product Desc will be here for produt name -13', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(14, 'MF/AM/1014', '', 'Produt Name -14', 'product Desc will be here for produt name -14', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Amino Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(15, 'MF/0115', '', 'Produt Name -15', 'product Desc will be here for produt name -15', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(16, 'MF/0216', '', 'Produt Name -16', 'product Desc will be here for produt name -16', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(17, 'MF/0317', '', 'Produt Name -17', 'product Desc will be here for produt name -17', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(18, 'AG/PA/0218', '', 'Produt Name -18', 'product Desc will be here for produt name -18', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(19, 'AG/SO/0219', '', 'Produt Name -19', 'product Desc will be here for produt name -19', 'Lit', 0.00, '', 'Agro Chemical', 'Solvent', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(20, 'AG/0120', '', 'Produt Name -20', '<p>product Desc will be here for produt name -20</p>', 'Kg', 0.00, '123456879AB', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-06-14'),
(21, 'AH/VM/0121', '', 'Produt Name -21', 'product Desc will be here for produt name -21', 'Kg', 0.00, '', 'Animal Feed', 'Vitamin', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(22, 'AG/PA/0322', '', 'Produt Name -22', 'product Desc will be here for produt name -22', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(23, 'MF/BG/0123', '', 'Produt Name -23', 'product Desc will be here for produt name -23', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Boron Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(24, 'MF/BG/0224', '', 'Produt Name -24', 'product Desc will be here for produt name -24', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Boron Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(25, 'AG/0225', '', 'Produt Name -25', 'product Desc will be here for produt name -25', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(26, 'MF/BG/0326', '', 'Produt Name -26', 'product Desc will be here for produt name -26', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Boron Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(27, 'MF/BG/0427', '', 'Produt Name -27', 'product Desc will be here for produt name -27', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Boron Group', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(28, 'AH/0228', '', 'Produt Name -28', 'product Desc will be here for produt name -28', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(29, 'AG/PA/0429', '', 'Produt Name -29', 'product Desc will be here for produt name -29', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(30, 'AH/0330', '', 'Produt Name -30', 'product Desc will be here for produt name -30', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(31, 'AH/0431', '', 'Produt Name -31', 'product Desc will be here for produt name -31', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(32, 'AG/0332', '', 'Produt Name -32', 'product Desc will be here for produt name -32', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(33, 'AG/0433', '', 'Produt Name -33', 'product Desc will be here for produt name -33', 'Kg', 0.00, 'hsnc-033', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(34, 'AG/PA/0534', '', 'Produt Name -34', 'product Desc will be here for produt name -34', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(35, 'MF/0435', '', 'Produt Name -35', 'product Desc will be here for produt name -35', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(36, 'MF/0536', '', 'Produt Name -36', 'product Desc will be here for produt name -36', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(37, 'AH/PR/0137', '', 'Produt Name -37', 'product Desc will be here for produt name -37', 'Kg', 0.00, '', 'Animal Feed', 'Preservative', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(38, 'MF/EC/0138', '', 'Produt Name -38', 'product Desc will be here for produt name -38', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(39, 'AH/0539', '', 'Produt Name -39', 'product Desc will be here for produt name -39', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(40, 'AH/0640', '', 'Produt Name -40', 'product Desc will be here for produt name -40', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(41, 'AG/PA/0641', '', 'Produt Name -41', 'product Desc will be here for produt name -41', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(42, 'AH/TE/0142', '', 'Produt Name -42', 'product Desc will be here for produt name -42', 'Kg', 0.00, '', 'Animal Feed', 'Trace Element', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(43, 'MF/MS/1343', '', 'Produt Name -43', 'product Desc will be here for produt name -43', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Metalic Sulphate', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(44, 'MF/MS/0144', '', 'Produt Name -44', 'product Desc will be here for produt name -44', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Metalic Sulphate', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(45, 'AG/5145', '', 'Produt Name -45', 'product Desc will be here for produt name -45', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(46, 'MF/MS/0246', '', 'Produt Name -46', 'product Desc will be here for produt name -46', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Metalic Sulphate', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(47, 'AH/0747', '', 'Produt Name -47', 'product Desc will be here for produt name -47', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(48, 'AH/0848', '', 'Produt Name -48', 'product Desc will be here for produt name -48', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(49, 'MF/PN/0149', '', 'Produt Name -49', 'product Desc will be here for produt name -49', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(50, 'AG/0550', '', 'Produt Name -50', 'product Desc will be here for produt name -50', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(51, 'AG/0651', '', 'Produt Name -51', 'product Desc will be here for produt name -51', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(52, 'MF/0652', '', 'Produt Name -52', 'product Desc will be here for produt name -52', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(53, 'AH/0953', '', 'Produt Name -53', 'product Desc will be here for produt name -53', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(54, 'AG/SO/0354', '', 'Produt Name -54', 'product Desc will be here for produt name -54', 'Kg', 0.00, '', 'Agro Chemical', 'Solvent', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(55, 'AG/SO/0455', '', 'Produt Name -55', 'product Desc will be here for produt name -55', 'Kg', 0.00, '', 'Agro Chemical', 'Solvent', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(56, 'MF/0756', '', 'Produt Name -56', 'product Desc will be here for produt name -56', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(57, 'AH/1057', '', 'Produt Name -57', 'product Desc will be here for produt name -57', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(58, 'AH/1158', '', 'Produt Name -58', 'product Desc will be here for produt name -58', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(59, 'AG/PA/0759', '', 'Produt Name -59', 'product Desc will be here for produt name -59', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(60, 'CS/0160', '', 'Produt Name -60', 'product Desc will be here for produt name -60', 'Kg', 0.00, '', 'Consumable', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(61, 'MF/EC/0261', '', 'Produt Name -61', 'product Desc will be here for produt name -61', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(62, 'MF/EC/0362', '', 'Produt Name -62', 'product Desc will be here for produt name -62', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(63, 'MF/EC/0463', '', 'Produt Name -63', 'product Desc will be here for produt name -63', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(64, 'MF/EC/0564', '', 'Produt Name -64', 'product Desc will be here for produt name -64', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(65, 'MF/EC/0665', '', 'Produt Name -65', 'product Desc will be here for produt name -65', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(66, 'MF/EC/0766', '', 'Produt Name -66', 'product Desc will be here for produt name -66', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(67, 'MF/EC/0867', '', 'Produt Name -67', 'product Desc will be here for produt name -67', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(68, 'MF/EC/0968', '', 'Produt Name -68', 'product Desc will be here for produt name -68', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(69, 'MF/EC/1069', '', 'Produt Name -69', 'product Desc will be here for produt name -69', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(70, 'MF/EC/1170', '', 'Produt Name -70', 'product Desc will be here for produt name -70', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'EDTA Chelates', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(71, 'AG/EM/0271', '', 'Produt Name -71', 'product Desc will be here for produt name -71', 'Kg', 0.00, '', 'Agro Chemical', 'Emulsifier', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(72, 'AH/TE/0272', '', 'Produt Name -72', 'product Desc will be here for produt name -72', 'Kg', 0.00, '', 'Animal Feed', 'Trace Element', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(73, 'MF/MS/0373', '', 'Produt Name -73', 'product Desc will be here for produt name -73', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Metalic Sulphate', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(74, 'MF/MS/0474', '', 'Produt Name -74', 'product Desc will be here for produt name -74', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Metalic Sulphate', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(75, 'PM/DR/0175', '', 'Produt Name -75', 'product Desc will be here for produt name -75', 'Nos', 0.00, '', 'Packing Material', 'Drum', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(76, 'AG/0776', '', 'Produt Name -76', 'product Desc will be here for produt name -76', 'Lit', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(77, 'MF/PN/0277', '', 'Produt Name -77', 'product Desc will be here for produt name -77', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(78, 'AH/1278', '', 'Produt Name -78', 'product Desc will be here for produt name -78', 'Lit', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(79, 'AH/1379', '', 'Produt Name -79', 'product Desc will be here for produt name -79', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(80, 'MF/PN/0380', '', 'Produt Name -80', 'product Desc will be here for produt name -80', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(81, 'AG/5281', '', 'Produt Name -81', 'product Desc will be here for produt name -81', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(82, 'AG/PA/0882', '', 'Produt Name -82', 'product Desc will be here for produt name -82', 'Lit', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(83, 'AG/PA/0983', '', 'Produt Name -83', 'product Desc will be here for produt name -83', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(84, 'AG/PA/1084', '', 'Produt Name -84', 'product Desc will be here for produt name -84', 'Kg', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(85, 'AG/PA/1185', '', 'Produt Name -85', 'product Desc will be here for produt name -85', 'Lit', 0.00, '', 'Agro Chemical', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(86, 'AH/PA/0186', '', 'Produt Name -86', 'product Desc will be here for produt name -86', 'Kg', 0.00, '', 'Animal Feed', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(87, 'AH/1487', '', 'Produt Name -87', 'product Desc will be here for produt name -87', 'Lit', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(88, 'AH/1588', '', 'Produt Name -88', 'product Desc will be here for produt name -88', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(89, 'AH/1689', '', 'Produt Name -89', 'product Desc will be here for produt name -89', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(90, 'AH/1790', '', 'Produt Name -90', 'product Desc will be here for produt name -90', 'Kg', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(91, 'AH/1891', '', 'Produt Name -91', 'product Desc will be here for produt name -91', 'Lit', 0.00, '', 'Animal Feed', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(92, 'MF/HS/0192', '', 'Produt Name -92', 'product Desc will be here for produt name -92', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Humic & Seawed', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(93, 'MF/HS/0293', '', 'Produt Name -93', 'product Desc will be here for produt name -93', 'Kg', 0.00, '', 'Micronutrient & Fertilizer', 'Humic & Seawed', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(94, 'AG/0894', '', 'Produt Name -94', 'product Desc will be here for produt name -94', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(95, 'AG/0995', '', 'Produt Name -95', 'product Desc will be here for produt name -95', 'Lit', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(96, 'AH/VM/0296', '', 'Produt Name -96', 'product Desc will be here for produt name -96', 'Kg', 0.00, '', 'Animal Feed', 'Vitamin', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(97, 'AG/SO/0597', '', 'Produt Name -97', 'product Desc will be here for produt name -97', 'Lit', 0.00, '', 'Agro Chemical', 'Solvent', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(98, 'AG/1098', '', 'Produt Name -98', 'product Desc will be here for produt name -98', 'Kg', 0.00, '', 'Agro Chemical', '', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(99, 'AH/VM/0399', '', 'Produt Name -99', 'product Desc will be here for produt name -99', 'Kg', 0.00, '', 'Animal Feed', 'Vitamin', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(100, 'AH/PA/02100', '', 'Produt Name -100', 'product Desc will be here for produt name -100', 'Kg', 0.00, '', 'Animal Feed', 'Processing Aid', 9.00, 9.00, 18.00, 0.00, 'No', 1, '2017-03-06'),
(434, 'PS/0311', '', 'Test Product', '<p>Product Description</p>', 'Nos', 10.00, '123456879AB', '', '', 9.00, 9.00, 18.00, 1150.00, 'No', 1, '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `product_batch_details`
--

CREATE TABLE IF NOT EXISTS `product_batch_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lot_no` varchar(20) NOT NULL,
  `bag_no` varchar(5) NOT NULL DEFAULT '0',
  `packing` float(10,2) NOT NULL DEFAULT '0.00',
  `sample_no` varchar(100) NOT NULL,
  `received_at` varchar(50) NOT NULL,
  `transporter` varchar(50) NOT NULL,
  `batch_remark` text NOT NULL,
  `invoice_firm` int(11) NOT NULL DEFAULT '1',
  `material_inward_no` varchar(26) NOT NULL,
  `manufacturing_date` varchar(7) NOT NULL DEFAULT '00-0000',
  `expiry_date` varchar(7) NOT NULL DEFAULT '00-0000',
  `tax_per` float(4,2) NOT NULL,
  `tax_type` varchar(6) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT '0',
  `excise` float(4,2) NOT NULL DEFAULT '0.00' COMMENT 'This is CGST perc',
  `added_by` int(3) NOT NULL,
  `purc_order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lot_no` (`lot_no`,`sample_no`,`transporter`),
  KEY `invoice_firm` (`invoice_firm`),
  KEY `added_by` (`added_by`),
  KEY `purc_ord_id` (`purc_order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1111 ;

--
-- Dumping data for table `product_batch_details`
--

INSERT INTO `product_batch_details` (`id`, `lot_no`, `bag_no`, `packing`, `sample_no`, `received_at`, `transporter`, `batch_remark`, `invoice_firm`, `material_inward_no`, `manufacturing_date`, `expiry_date`, `tax_per`, `tax_type`, `tax_id`, `excise`, `added_by`, `purc_order_id`) VALUES
(1107, 'JE-16-17-5', '25', 10.00, '', '', '', '', 1, 'JE/16-17/DCI/4', '06-2017', '12-2020', 9.00, 'SGST', 13, 9.00, 1, 0),
(1108, 'JE-16-17-6', '20', 25.00, 'NA', '', '', '', 1, 'JE/16-17/DCI/5', '06-2017', '', 9.00, 'SGST', 13, 9.00, 1, 0),
(1109, 'JE-16-17-7', '10', 25.00, '', '', '', '', 1, 'JE/16-17/DCI/6', '', '', 6.00, 'SGST', 16, 6.00, 1, 0),
(1110, '1', '0', 0.00, '', '', '', 'Opening Stock', 1, '', '00-0000', '00-0000', 0.00, '', 0, 0.00, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_org`
--

CREATE TABLE IF NOT EXISTS `product_org` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_desc` text NOT NULL,
  `prod_unit` varchar(3) NOT NULL DEFAULT 'Kg',
  `min_qty` float(7,2) NOT NULL DEFAULT '0.00',
  `hsn_code` varchar(50) NOT NULL,
  `marketing_talk` text NOT NULL,
  `product_keywords` text NOT NULL,
  `product_packing` int(11) NOT NULL,
  `crop_categories` varchar(256) NOT NULL,
  `disease_categories` varchar(256) NOT NULL,
  `prod_gravity` float(10,2) NOT NULL DEFAULT '1.00',
  `product_category` varchar(100) NOT NULL,
  `sub_category` varchar(100) NOT NULL,
  `updated_by` int(11) NOT NULL COMMENT 'users->uid',
  `updated_date` date NOT NULL,
  `horizon_item_code` varchar(50) NOT NULL,
  `alligo_item_code` varchar(50) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `item_code` (`product_brand`,`product_name`),
  KEY `min_qty` (`min_qty`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `product_org`
--

INSERT INTO `product_org` (`pid`, `item_code`, `product_brand`, `product_name`, `product_desc`, `prod_unit`, `min_qty`, `hsn_code`, `marketing_talk`, `product_keywords`, `product_packing`, `crop_categories`, `disease_categories`, `prod_gravity`, `product_category`, `sub_category`, `updated_by`, `updated_date`, `horizon_item_code`, `alligo_item_code`) VALUES
(1, 'AG/SO/011', '', 'Produt Name -1', 'product Desc will be here for produt name -1', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Solvent', 1, '2017-03-06', 'AG/A1', 'AG/A1'),
(2, 'AG/PA/012', '', 'Produt Name -2', 'product Desc will be here for produt name -2', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/A2', ''),
(3, 'AH/013', '', 'Produt Name -3', 'product Desc will be here for produt name -3', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/A2', 'AH/A2'),
(4, 'AG/EM/014', '', 'Produt Name -4', 'product Desc will be here for produt name -4', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Emulsifier', 1, '2017-03-06', 'AG/A3', 'AG/A3'),
(5, 'MF/AM/015', '', 'Produt Name -5', 'product Desc will be here for produt name -5', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A4', 'AG/A4'),
(6, 'MF/AM/026', '', 'Produt Name -6', 'product Desc will be here for produt name -6', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A5', 'AG/A5'),
(7, 'MF/AM/037', '', 'Produt Name -7', 'product Desc will be here for produt name -7', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A6', 'AG/A6'),
(8, 'MF/AM/048', '', 'Produt Name -8', 'product Desc will be here for produt name -8', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A7', 'AG/A7'),
(9, 'MF/AM/059', '', 'Produt Name -9', 'product Desc will be here for produt name -9', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A8', 'AG/A8'),
(10, 'MF/AM/0610', '', 'Produt Name -10', 'product Desc will be here for produt name -10', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A9', 'AG/A9'),
(11, 'MF/AM/0711', '', 'Produt Name -11', 'product Desc will be here for produt name -11', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A10', 'AG/A10'),
(12, 'MF/AM/0812', '', 'Produt Name -12', 'product Desc will be here for produt name -12', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A11', 'AG/A11'),
(13, 'MF/AM/0913', '', 'Produt Name -13', 'product Desc will be here for produt name -13', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A12', 'AG/A12'),
(14, 'MF/AM/1014', '', 'Produt Name -14', 'product Desc will be here for produt name -14', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Amino Group', 1, '2017-03-06', 'AG/A13', 'AG/A13'),
(15, 'MF/0115', '', 'Produt Name -15', 'product Desc will be here for produt name -15', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/A14', 'AG/A14'),
(16, 'MF/0216', '', 'Produt Name -16', 'product Desc will be here for produt name -16', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'Ag/A15', 'Ag/A15'),
(17, 'MF/0317', '', 'Produt Name -17', 'product Desc will be here for produt name -17', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/A16', 'AG/A16'),
(18, 'AG/PA/0218', '', 'Produt Name -18', 'product Desc will be here for produt name -18', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/A17', 'AG/A17'),
(19, 'AG/SO/0219', '', 'Produt Name -19', 'product Desc will be here for produt name -19', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Solvent', 1, '2017-03-06', 'AG/B2', 'AG/B2'),
(20, 'AG/0120', '', 'Produt Name -20', '<p>product Desc will be here for produt name -20</p>', 'Kg', 0.00, '123456879AB', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-06-14', 'AH/B2', 'AH/B2'),
(21, 'AH/VM/0121', '', 'Produt Name -21', 'product Desc will be here for produt name -21', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Vitamin', 1, '2017-03-06', 'AH/B3', 'AH/B3'),
(22, 'AG/PA/0322', '', 'Produt Name -22', 'product Desc will be here for produt name -22', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/B3', 'AG/B3'),
(23, 'MF/BG/0123', '', 'Produt Name -23', 'product Desc will be here for produt name -23', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Boron Group', 1, '2017-03-06', 'AG/B3', 'AG/B3'),
(24, 'MF/BG/0224', '', 'Produt Name -24', 'product Desc will be here for produt name -24', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Boron Group', 1, '2017-03-06', 'AG/B4', 'AG/B4'),
(25, 'AG/0225', '', 'Produt Name -25', 'product Desc will be here for produt name -25', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/B5', 'AG/B5'),
(26, 'MF/BG/0326', '', 'Produt Name -26', 'product Desc will be here for produt name -26', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Boron Group', 1, '2017-03-06', 'AG/B6', 'AG/B6'),
(27, 'MF/BG/0427', '', 'Produt Name -27', 'product Desc will be here for produt name -27', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Boron Group', 1, '2017-03-06', 'AG/B7', ''),
(28, 'AH/0228', '', 'Produt Name -28', 'product Desc will be here for produt name -28', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/B4', 'AH/B4'),
(29, 'AG/PA/0429', '', 'Produt Name -29', 'product Desc will be here for produt name -29', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/B8', 'AG/B8'),
(30, 'AH/0330', '', 'Produt Name -30', 'product Desc will be here for produt name -30', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/B5', 'AH/B5'),
(31, 'AH/0431', '', 'Produt Name -31', 'product Desc will be here for produt name -31', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/B6', 'AH/B6'),
(32, 'AG/0332', '', 'Produt Name -32', 'product Desc will be here for produt name -32', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/C1', 'AG/C1'),
(33, 'AG/0433', '', 'Produt Name -33', 'product Desc will be here for produt name -33', 'Kg', 0.00, 'hsnc-033', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/C2', 'AG/C2'),
(34, 'AG/PA/0534', '', 'Produt Name -34', 'product Desc will be here for produt name -34', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/C3', 'AG/C3'),
(35, 'MF/0435', '', 'Produt Name -35', 'product Desc will be here for produt name -35', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/C4', 'AG/C4'),
(36, 'MF/0536', '', 'Produt Name -36', 'product Desc will be here for produt name -36', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/C5', 'AG/C5'),
(37, 'AH/PR/0137', '', 'Produt Name -37', 'product Desc will be here for produt name -37', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Preservative', 1, '2017-03-06', 'AH/C1', 'AH/C1'),
(38, 'MF/EC/0138', '', 'Produt Name -38', 'product Desc will be here for produt name -38', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/C6', 'AG/C6'),
(39, 'AH/0539', '', 'Produt Name -39', 'product Desc will be here for produt name -39', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/C3', 'AH/C3'),
(40, 'AH/0640', '', 'Produt Name -40', 'product Desc will be here for produt name -40', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/C4', 'AH/C4'),
(41, 'AG/PA/0641', '', 'Produt Name -41', 'product Desc will be here for produt name -41', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AH/C5', 'AH/C5'),
(42, 'AH/TE/0142', '', 'Produt Name -42', 'product Desc will be here for produt name -42', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Trace Element', 1, '2017-03-06', 'AH/C6', 'AH/C6'),
(43, 'MF/MS/1343', '', 'Produt Name -43', 'product Desc will be here for produt name -43', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Metalic Sulphate', 1, '2017-03-06', 'AG/C8', 'AG/C8'),
(44, 'MF/MS/0144', '', 'Produt Name -44', 'product Desc will be here for produt name -44', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Metalic Sulphate', 1, '2017-03-06', 'AG/C9', 'AG/C9'),
(45, 'AG/5145', '', 'Produt Name -45', 'product Desc will be here for produt name -45', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/C10', 'AG/C10'),
(46, 'MF/MS/0246', '', 'Produt Name -46', 'product Desc will be here for produt name -46', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Metalic Sulphate', 1, '2017-03-06', '', ''),
(47, 'AH/0747', '', 'Produt Name -47', 'product Desc will be here for produt name -47', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AG/C11', 'AG/C11'),
(48, 'AH/0848', '', 'Produt Name -48', 'product Desc will be here for produt name -48', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/C9', 'AH/C9'),
(49, 'MF/PN/0149', '', 'Produt Name -49', 'product Desc will be here for produt name -49', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 1, '2017-03-06', 'AG/D1', 'AG/D1'),
(50, 'AG/0550', '', 'Produt Name -50', 'product Desc will be here for produt name -50', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/D2', 'AG/D2'),
(51, 'AG/0651', '', 'Produt Name -51', 'product Desc will be here for produt name -51', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/D3', 'AG/D3'),
(52, 'MF/0652', '', 'Produt Name -52', 'product Desc will be here for produt name -52', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/D4', 'AG/D4'),
(53, 'AH/0953', '', 'Produt Name -53', 'product Desc will be here for produt name -53', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/D2', 'AH/D2'),
(54, 'AG/SO/0354', '', 'Produt Name -54', 'product Desc will be here for produt name -54', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Solvent', 1, '2017-03-06', 'AG/D5', 'AG/D5'),
(55, 'AG/SO/0455', '', 'Produt Name -55', 'product Desc will be here for produt name -55', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Solvent', 1, '2017-03-06', 'AG/D6', 'AG/D6'),
(56, 'MF/0756', '', 'Produt Name -56', 'product Desc will be here for produt name -56', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', '', 1, '2017-03-06', 'AG/D7', 'AG/D7'),
(57, 'AH/1057', '', 'Produt Name -57', 'product Desc will be here for produt name -57', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/D3', 'AH/D3'),
(58, 'AH/1158', '', 'Produt Name -58', 'product Desc will be here for produt name -58', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/D3', 'AH/D3'),
(59, 'AG/PA/0759', '', 'Produt Name -59', 'product Desc will be here for produt name -59', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/D8', 'AG/D8'),
(60, 'CS/0160', '', 'Produt Name -60', 'product Desc will be here for produt name -60', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Consumable', '', 1, '2017-03-06', 'AG/D0', 'AG/D0'),
(61, 'MF/EC/0261', '', 'Produt Name -61', 'product Desc will be here for produt name -61', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E1', 'AG/E1'),
(62, 'MF/EC/0362', '', 'Produt Name -62', 'product Desc will be here for produt name -62', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E2', 'AG/E2'),
(63, 'MF/EC/0463', '', 'Produt Name -63', 'product Desc will be here for produt name -63', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E3', 'AG/E3'),
(64, 'MF/EC/0564', '', 'Produt Name -64', 'product Desc will be here for produt name -64', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E4', 'AG/E4'),
(65, 'MF/EC/0665', '', 'Produt Name -65', 'product Desc will be here for produt name -65', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E5', 'AG/E5'),
(66, 'MF/EC/0766', '', 'Produt Name -66', 'product Desc will be here for produt name -66', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E6', 'AG/E6'),
(67, 'MF/EC/0867', '', 'Produt Name -67', 'product Desc will be here for produt name -67', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E7', 'AG/E7'),
(68, 'MF/EC/0968', '', 'Produt Name -68', 'product Desc will be here for produt name -68', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E8', 'AG/E8'),
(69, 'MF/EC/1069', '', 'Produt Name -69', 'product Desc will be here for produt name -69', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E9', 'AG/E9'),
(70, 'MF/EC/1170', '', 'Produt Name -70', 'product Desc will be here for produt name -70', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'EDTA Chelates', 1, '2017-03-06', 'AG/E10', 'AG/E10'),
(71, 'AG/EM/0271', '', 'Produt Name -71', 'product Desc will be here for produt name -71', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Emulsifier', 1, '2017-03-06', 'AG/E11', 'AG/E11'),
(72, 'AH/TE/0272', '', 'Produt Name -72', 'product Desc will be here for produt name -72', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Trace Element', 1, '2017-03-06', '', ''),
(73, 'MF/MS/0373', '', 'Produt Name -73', 'product Desc will be here for produt name -73', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Metalic Sulphate', 1, '2017-03-06', 'AG/F1', 'AG/F1'),
(74, 'MF/MS/0474', '', 'Produt Name -74', 'product Desc will be here for produt name -74', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Metalic Sulphate', 1, '2017-03-06', 'AG/F2', 'AG/F2'),
(75, 'PM/DR/0175', '', 'Produt Name -75', 'product Desc will be here for produt name -75', 'Nos', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Packing Material', 'Drum', 1, '2017-03-06', 'AG/PK/F1', 'AG/FD25'),
(76, 'AG/0776', '', 'Produt Name -76', 'product Desc will be here for produt name -76', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/F3', 'AG/F3'),
(77, 'MF/PN/0277', '', 'Produt Name -77', 'product Desc will be here for produt name -77', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 1, '2017-03-06', 'AH/F3', 'AH/F3'),
(78, 'AH/1278', '', 'Produt Name -78', 'product Desc will be here for produt name -78', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/F4', 'AH/F4'),
(79, 'AH/1379', '', 'Produt Name -79', 'product Desc will be here for produt name -79', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/F5', 'AH/F5'),
(80, 'MF/PN/0380', '', 'Produt Name -80', 'product Desc will be here for produt name -80', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Plant Nutrition Chemical', 1, '2017-03-06', 'AG/F4', 'AG/F4'),
(81, 'AG/5281', '', 'Produt Name -81', 'product Desc will be here for produt name -81', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AH/F6', 'AH/F6'),
(82, 'AG/PA/0882', '', 'Produt Name -82', 'product Desc will be here for produt name -82', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/G1', 'AG/G1'),
(83, 'AG/PA/0983', '', 'Produt Name -83', 'product Desc will be here for produt name -83', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/G2', 'AG/G2'),
(84, 'AG/PA/1084', '', 'Produt Name -84', 'product Desc will be here for produt name -84', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/G3', 'AG/G3'),
(85, 'AG/PA/1185', '', 'Produt Name -85', 'product Desc will be here for produt name -85', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Processing Aid', 1, '2017-03-06', 'AG/G4', 'AG/G4'),
(86, 'AH/PA/0186', '', 'Produt Name -86', 'product Desc will be here for produt name -86', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Processing Aid', 1, '2017-03-06', 'AH/G1', 'AH/G1'),
(87, 'AH/1487', '', 'Produt Name -87', 'product Desc will be here for produt name -87', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/G2', 'AH/G2'),
(88, 'AH/1588', '', 'Produt Name -88', 'product Desc will be here for produt name -88', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/H1', 'AH/H1'),
(89, 'AH/1689', '', 'Produt Name -89', 'product Desc will be here for produt name -89', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/H2', 'AH/H2'),
(90, 'AH/1790', '', 'Produt Name -90', 'product Desc will be here for produt name -90', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/H3', 'AH/H3'),
(91, 'AH/1891', '', 'Produt Name -91', 'product Desc will be here for produt name -91', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', '', 1, '2017-03-06', 'AH/H4', 'AH/H4'),
(92, 'MF/HS/0192', '', 'Produt Name -92', 'product Desc will be here for produt name -92', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Humic & Seawed', 1, '2017-03-06', 'AG/H1', 'AG/H1'),
(93, 'MF/HS/0293', '', 'Produt Name -93', 'product Desc will be here for produt name -93', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Micronutrient & Fertilizer', 'Humic & Seawed', 1, '2017-03-06', 'AG / H2', 'AG / H2'),
(94, 'AG/0894', '', 'Produt Name -94', 'product Desc will be here for produt name -94', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/H3', 'AG/H3'),
(95, 'AG/0995', '', 'Produt Name -95', 'product Desc will be here for produt name -95', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/H4', 'AG/H4'),
(96, 'AH/VM/0296', '', 'Produt Name -96', 'product Desc will be here for produt name -96', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Vitamin', 1, '2017-03-06', 'AH/I1', 'AH/I1'),
(97, 'AG/SO/0597', '', 'Produt Name -97', 'product Desc will be here for produt name -97', 'Lit', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', 'Solvent', 1, '2017-03-06', 'AG/ I1', 'AG/ I1'),
(98, 'AG/1098', '', 'Produt Name -98', 'product Desc will be here for produt name -98', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Agro Chemical', '', 1, '2017-03-06', 'AG/K1', 'AG/K1'),
(99, 'AH/VM/0399', '', 'Produt Name -99', 'product Desc will be here for produt name -99', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Vitamin', 1, '2017-03-06', 'AH/L1', 'AH/L1'),
(100, 'AH/PA/02100', '', 'Produt Name -100', 'product Desc will be here for produt name -100', 'Kg', 0.00, '', 'typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining', '', 0, '', '', 1.00, 'Animal Feed', 'Processing Aid', 1, '2017-03-06', 'AH/L2', 'AH/L2');

-- --------------------------------------------------------

--
-- Table structure for table `product_specifications`
--

CREATE TABLE IF NOT EXISTS `product_specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `spec_name` varchar(250) NOT NULL,
  `document_name` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `product_specifications`
--

INSERT INTO `product_specifications` (`id`, `product_id`, `spec_name`, `document_name`) VALUES
(12, 433, 'test Document', 'test_document_aa_po_17-18_27.pdf'),
(11, 411, 'test spec2', 'test_spec2_aa-17-18-in-1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `product_stock`
--

CREATE TABLE IF NOT EXISTS `product_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `comp_id` int(10) NOT NULL DEFAULT '0',
  `su_id` int(10) NOT NULL DEFAULT '0',
  `invoice_no` varchar(25) NOT NULL,
  `order_id` int(11) NOT NULL,
  `challan_no` varchar(25) NOT NULL,
  `inw_qty` float(10,2) NOT NULL,
  `outw_qty` float(10,2) NOT NULL,
  `lot_no` varchar(20) NOT NULL,
  `rate` float(10,2) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `instock` float(10,2) NOT NULL,
  `on_date` date NOT NULL,
  `batch_desc` text NOT NULL,
  `firm_id` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`comp_id`,`su_id`,`invoice_no`),
  KEY `lot_no` (`lot_no`),
  KEY `order_id` (`order_id`,`challan_no`),
  KEY `firm_id` (`firm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1189 ;

--
-- Dumping data for table `product_stock`
--

INSERT INTO `product_stock` (`id`, `pid`, `comp_id`, `su_id`, `invoice_no`, `order_id`, `challan_no`, `inw_qty`, `outw_qty`, `lot_no`, `rate`, `amount`, `instock`, `on_date`, `batch_desc`, `firm_id`) VALUES
(1184, 51, 1490, 0, 'JE/16-17/IN/520', 12, '', 0.00, 50.00, '', 300.00, 15000.00, 0.00, '2017-06-15', '', 1),
(1185, 33, 0, 472, 'custom-in-11', 0, '', 250.00, 0.00, 'JE-16-17-7', 15.00, 3750.00, 250.00, '2017-06-14', '', 1),
(1183, 33, 1490, 0, 'JE/16-17/IN/520', 12, '', 0.00, 100.00, '', 20.00, 2000.00, 0.00, '2017-06-15', '', 1),
(1182, 33, 1491, 0, 'JE/16-17/IN/519', 11, '', 0.00, 10.00, '', 250.00, 2500.00, 0.00, '2017-06-15', '', 1),
(1181, 51, 1491, 0, 'JE/16-17/IN/519', 11, '', 0.00, 20.00, '', 255.00, 5100.00, 0.00, '2017-06-15', '', 1),
(1180, 33, 0, 483, 'Invoice/17-18/3', 0, '', 500.00, 0.00, 'JE-16-17-6', 147.00, 73500.00, 500.00, '2017-06-15', '', 1),
(1179, 51, 0, 483, 'Invoice/17-18/3', 0, '', 250.00, 0.00, 'JE-16-17-5', 125.50, 31375.00, 250.00, '2017-06-15', '', 1),
(1186, 434, 0, 1, '', 0, '', 10.00, 0.00, '1', 500.00, 5000.00, 10.00, '2017-06-21', 'Opening Stock', 1),
(1187, 32, 1492, 0, 'JE/16-17/I/521', 13, '', 0.00, 2.00, '', 1100.00, 2200.00, 0.00, '2017-06-21', '', 1),
(1188, 94, 1492, 0, 'JE/16-17/I/521', 13, '', 0.00, 1.00, '', 1200.00, 1200.00, 0.00, '2017-06-21', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `purc_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `purc_order_number` varchar(50) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  `order_by` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `firm_id` int(3) NOT NULL,
  `tax_type` varchar(10) NOT NULL DEFAULT '',
  `tax_per` float(5,2) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `excise` float(5,2) NOT NULL,
  `pay_term` varchar(100) NOT NULL,
  `payment_reminder` int(3) NOT NULL,
  `expected_delivery` date NOT NULL,
  `transport_name` varchar(256) NOT NULL,
  `delivery_address` varchar(100) NOT NULL,
  `order_remark` text NOT NULL,
  `order_date` date NOT NULL,
  `forwardingAmt` float(10,2) NOT NULL,
  `discountAmt` float(10,2) NOT NULL,
  `otherAdjustment` float(10,2) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  `status` enum('Open','Closed','Confirmed','Completed') NOT NULL DEFAULT 'Open',
  `account_confirmed` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1- Confirmed, 0- Confirmation Pending',
  PRIMARY KEY (`purc_order_id`),
  KEY `enquiry_id` (`enquiry_id`,`order_by`,`firm_id`,`status`),
  KEY `supplier_id` (`supplier_id`),
  KEY `order_date` (`order_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`purc_order_id`, `purc_order_number`, `enquiry_id`, `order_by`, `supplier_id`, `firm_id`, `tax_type`, `tax_per`, `tax_id`, `excise`, `pay_term`, `payment_reminder`, `expected_delivery`, `transport_name`, `delivery_address`, `order_remark`, `order_date`, `forwardingAmt`, `discountAmt`, `otherAdjustment`, `updated_by`, `updated_date`, `status`, `account_confirmed`) VALUES
(2, 'AH/PO/15-16/4', 345, 1, 472, 2, '', 0.00, 0, 12.50, 'After Received Material', 45, '2017-02-16', 'Vishal Transport', 'Heramb', 'Order Remark here\r\nLine 213', '2017-02-09', 500.00, 0.00, 2500.00, 25, '2017-02-11', 'Closed', '0'),
(4, 'HA/PO/15-16/6', 344, 1, 472, 1, '', 0.00, 0, 1.00, '', 30, '2017-02-17', 'New India Transaport', 'Heramb Horizon Factory th Mail Nashik', 'Order Remark', '2017-02-11', 300.00, 226.00, 2700.00, 25, '2017-03-23', 'Closed', '1'),
(5, 'HA/PO/15-16/7', 346, 1, 472, 1, '', 0.00, 0, 0.00, '', 30, '0000-00-00', '', '', '', '2017-02-16', 0.00, 0.00, 0.00, 25, '2017-02-16', 'Closed', '0'),
(6, 'HA/PO/15-16/8', 347, 1, 472, 1, 'CST', 2.00, 1, 1.00, 'After Received Material', 30, '2017-02-24', '', '', 'Order Remark \r\nhere', '2017-02-17', 2500.00, 550.00, 3.00, 25, '2017-02-17', 'Completed', '1'),
(7, 'HA/PO/15-16/9', 348, 1, 472, 1, 'CST', 2.00, 1, 1.00, '', 30, '2017-03-31', 'Vishal Transport', 'Heramb1', 'Order Remark', '2017-02-18', 550.00, 0.00, 2500.00, 1, '2017-03-23', 'Confirmed', '0'),
(8, 'HA/PO/15-16/10', 342, 1, 472, 1, 'VAT', 2.00, 5, 0.00, '', 30, '2017-03-31', 'VRL', '', '', '2017-02-21', 400.00, 0.00, 0.00, 25, '2017-03-24', 'Confirmed', '1'),
(9, 'AL/PO/15-16/5', 351, 1, 472, 2, '', 0.00, 0, 0.00, '', 30, '0000-00-00', '', '', '', '2017-03-03', 250.00, 50.00, 0.00, 25, '2017-03-03', 'Completed', '1'),
(10, 'HA/PO/15-16/11', 352, 1, 472, 1, 'CST', 2.00, 1, 0.00, '30 Days credit', 30, '2017-03-20', '', 'Horizon Factory', 'Here will be the order remark', '2017-03-09', 500.00, 70.00, 0.00, 25, '2017-03-09', 'Completed', '0'),
(11, 'HA/PO/15-16/12', 354, 1, 472, 1, 'CST', 6.00, 4, 0.00, '30 Days credit', 30, '2017-03-31', 'Vishal Transport', 'Horizon Factory', 'Order Remark will be here', '2017-03-24', 500.00, 0.00, 200.00, 25, '2017-03-24', 'Completed', '0'),
(12, 'HA/PO/15-16/13', 355, 1, 472, 1, '', 0.00, 0, 0.00, '', 30, '0000-00-00', '', '', '', '2017-04-03', 0.00, 0.00, 0.00, 25, '2017-04-03', 'Confirmed', '0'),
(13, 'AH/PO/2017/1', 356, 1, 472, 7, 'CST', 2.00, 1, 0.00, 'After 30 days', 30, '2017-04-11', 'VRL', 'Heramb1', '', '2017-04-06', 0.00, 0.00, 0.00, 25, '2017-04-06', 'Confirmed', '1'),
(14, 'A1/PO/15-16/14', 357, 1, 472, 1, '', 0.00, 0, 0.00, '', 30, '0000-00-00', '', '', '', '2017-06-08', 0.00, 0.00, 0.00, 4, '2017-06-08', 'Confirmed', '0'),
(15, '/PO//', 0, 1, 481, 481, 'SGST', 9.00, 13, 9.00, 'After Received Material', 30, '0000-00-00', '', '', 'Order Remark', '2017-06-17', 0.00, 0.00, 0.00, 1, '2017-06-17', 'Open', '0'),
(16, '/PO//', 0, 1, 481, 481, 'SGST', 9.00, 13, 9.00, 'After Received Material', 30, '0000-00-00', '', '', 'Order Remark', '2017-06-17', 0.00, 0.00, 0.00, 1, '2017-06-17', 'Open', '0'),
(17, 'JE/PO/16-17/1', 0, 1, 481, 1, 'SGST', 9.00, 13, 9.00, 'After Received Material', 30, '0000-00-00', '', '', 'Order Remark', '2017-06-17', 0.00, 100.00, 0.00, 1, '2017-06-17', 'Confirmed', '0'),
(18, 'JE/PO/16-17/2', 0, 1, 1, 1, 'SGST', 6.00, 16, 6.00, 'After Received Material', 30, '0000-00-00', '', '', 'Order Remark', '2017-06-20', 0.00, 0.00, 0.00, 1, '2017-06-20', 'Confirmed', '0');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_payments`
--

CREATE TABLE IF NOT EXISTS `purchase_order_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_num` varchar(50) NOT NULL,
  `material_inward_no` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `po_amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'This is actual invoice amount of supplier',
  `paid_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `firm_id` int(3) NOT NULL,
  `po_by` int(11) NOT NULL,
  `status` enum('Pending','Paid') NOT NULL DEFAULT 'Pending',
  `reminder_date` date NOT NULL,
  `purc_order_id` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `client_id` (`supplier_id`,`status`,`reminder_date`),
  KEY `firm_id` (`firm_id`),
  KEY `order_id` (`purc_order_id`,`updated_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `purchase_order_payments`
--

INSERT INTO `purchase_order_payments` (`payment_id`, `invoice_num`, `material_inward_no`, `supplier_id`, `po_amount`, `paid_amount`, `firm_id`, `po_by`, `status`, `reminder_date`, `purc_order_id`, `updated_by`, `updated_date`) VALUES
(2, 'Aadeshwar Chemicals - 12', '', 348, 190300.00, 0.00, 1, 25, 'Pending', '2017-03-31', 6, 23, '2017-03-01'),
(3, 'Invoice Number', '', 136, 79285.00, 20000.00, 1, 25, 'Pending', '2017-03-20', 7, 23, '2017-03-02'),
(4, 'Invoice Number 1234', '', 348, 2000.00, 0.00, 2, 25, 'Pending', '2017-04-02', 9, 23, '2017-03-03'),
(5, 'Invoice Number 234', '', 348, 2000.00, 0.00, 2, 25, 'Pending', '2017-04-02', 9, 23, '2017-03-03'),
(6, 'Invoice Number 2341', '', 348, 2000.00, 1000.00, 2, 25, 'Pending', '2017-04-02', 9, 23, '2017-03-03'),
(7, 'INV-HA/PO/15-16/11', '', 264, 111100.00, 0.00, 1, 25, 'Pending', '2017-04-09', 10, 23, '2017-03-10'),
(8, 'Invoice Number', '', 194, 75000.00, 0.00, 1, 25, 'Pending', '2017-03-18', 5, 23, '2017-03-10'),
(9, 'Invoice Number', '', 65, 5125406.00, 0.00, 2, 25, 'Pending', '2017-04-01', 2, 23, '2017-03-14'),
(10, 'Invoice Number 12345', '', 65, 5125406.00, 500000.00, 2, 25, 'Pending', '2017-05-06', 2, 23, '2017-03-22'),
(11, 'INV-24-mar-1', '', 136, 79284.80, 0.00, 1, 25, 'Pending', '2017-04-23', 7, 23, '2017-03-24'),
(12, 'INV-24-mar-10', 'HA/15-16/DCI/354', 319, 80200.00, 0.00, 1, 25, 'Pending', '2017-04-23', 11, 12, '2017-03-31'),
(13, 'Invoice Number 2017-01', 'AH/2017/DCI/1', 264, 30600.00, 0.00, 7, 25, 'Pending', '2017-05-06', 13, 12, '2017-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_products`
--

CREATE TABLE IF NOT EXISTS `purchase_order_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purc_order_id` int(11) NOT NULL,
  `purchase_pid` int(11) NOT NULL,
  `purchase_qty` float(10,2) NOT NULL,
  `purchase_rate` float(10,2) NOT NULL,
  `packing_size` float(10,2) NOT NULL,
  `packing` text NOT NULL,
  `prod_ref_name` varchar(100) NOT NULL,
  `make` varchar(50) NOT NULL,
  `notes` text NOT NULL,
  `total_inword` float(10,2) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purc_order_id` (`purc_order_id`,`purchase_pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `purchase_order_products`
--

INSERT INTO `purchase_order_products` (`id`, `purc_order_id`, `purchase_pid`, `purchase_qty`, `purchase_rate`, `packing_size`, `packing`, `prod_ref_name`, `make`, `notes`, `total_inword`, `updated_by`, `updated_date`) VALUES
(1, 2, 20, 500.00, 8500.00, 25.00, 'Drum', 'Benzoic Acid', '', 'Some notes are here', 400.00, 25, '2017-02-09'),
(2, 2, 50, 50.00, 500.00, 5.00, 'Drum', 'Dextrose Anhydrous', '', 'Some notes are here 123456', 50.00, 25, '2017-02-09'),
(3, 2, 101, 1000.00, 53.00, 25.00, 'Bags', 'Humic Acid Powder', '', 'Some notes are here 45678hh ', 500.00, 25, '2017-02-09'),
(5, 2, 32, 500.00, 450.50, 25.00, 'Bags', 'Calcium Carbonate', '', '-', 399.50, 25, '2017-02-09'),
(6, 3, 25, 500.00, 125.20, 25.50, 'Bags', 'Bordo', '', 'Some notes are here 1qcfg hfg', 0.00, 25, '2017-02-11'),
(7, 4, 25, 500.00, 125.20, 25.50, 'Bags', 'Bordo', '', 'Some notes are here Some notes are here', 0.00, 25, '2017-02-11'),
(8, 5, 33, 500.00, 150.00, 10.00, 'HDPE Bags', 'Calcium chloride (AG/04)', '', 'sas sassas a sa', 498.00, 25, '2017-02-16'),
(9, 6, 20, 250.00, 550.00, 10.00, 'HDPE Bag', 'Benzoic acid', '', 'With brown color', 250.00, 25, '2017-02-17'),
(10, 6, 32, 300.00, 176.00, 5.00, 'Pouch', 'Calcium Carbonate', '', 'With White color', 300.00, 25, '2017-02-17'),
(11, 7, 51, 200.00, 175.00, 25.00, 'Bags', 'Dextrose Monohydrate', '', 'This is sample comment.\r\nLine 1', 150.00, 25, '2017-02-18'),
(12, 7, 51, 200.00, 195.00, 20.00, 'Bags', 'Dextrose Monohydrate', '', 'This is sample comment.\r\nLine 2', 200.00, 25, '2017-02-18'),
(13, 8, 11, 1000.00, 80.00, 0.00, 'Bags', 'Amino Chelated Magnessium ', '', '10Kg', 0.00, 1, '2017-02-21'),
(14, 9, 60, 100.00, 10.00, 1.00, 'HDPE Bag', 'Dummy Product For Trials And Adjustment', '', 'This is test', 100.00, 25, '2017-03-03'),
(15, 9, 60, 100.00, 8.00, 5.00, 'HDPE Bag', 'Dummy Product For Trials And Adjustment', '', 'This is again for test', 100.00, 25, '2017-03-03'),
(16, 10, 5, 500.00, 157.00, 25.00, 'Bags', 'Amino Acid 40 (MF/AM/01)', '', 'liner bags', 500.00, 25, '2017-03-09'),
(17, 10, 33, 200.00, 150.00, 25.00, 'HDPE Bag', 'Calcium Chloride (AG/04)', '', '25kg packing with HDPE bag', 200.00, 25, '2017-03-09'),
(18, 8, 32, 500.00, 150.00, 25.00, 'Bags', 'Calcium Carbonate', '', 'Notes are here, \r\nBags with 25Kg Packing', 0.00, 25, '2017-03-24'),
(19, 11, 76, 500.00, 150.00, 25.00, 'Bags', 'Fish Oil (AG/07)', '', '', 500.00, 25, '2017-03-24'),
(20, 11, 103, 200.00, 100.00, 10.00, 'Bags', 'Magnesium Nitrate (AG/11)', '', '', 200.00, 25, '2017-03-24'),
(21, 12, 25, 1.00, 1.00, 1.00, 'Bag', 'Bordo (AG/02)', '', '', 0.00, 25, '2017-04-03'),
(22, 13, 177, 300.00, 150.00, 20.00, 'Bags', 'Zinc Sulphate Mono (AH/TE/07)', '', '', 200.00, 25, '2017-04-06'),
(23, 13, 25, 500.00, 50.25, 20.00, 'Bags', 'Bordo (AG/02)', 'Alligo', 'This is test', 0.00, 25, '2017-04-25'),
(24, 14, 33, 500.00, 120.00, 25.00, 'Bags', 'Produt Name -33 (AG/0433)', '', 'HDPE bags', 0.00, 4, '2017-06-08'),
(25, 14, 50, 5000.00, 100.00, 50.00, 'Bags', 'Produt Name -50 (AG/0550)', '', 'HDPE Bags', 4000.00, 4, '2017-06-08'),
(26, 16, 33, 300.00, 150.00, 0.00, '', '', '', 'Notes 1', 0.00, 1, '2017-06-17'),
(27, 16, 51, 400.00, 200.00, 0.00, '', '', '', 'Notes 2', 0.00, 1, '2017-06-17'),
(28, 17, 33, 300.00, 150.00, 0.00, '', '', '', 'Notes 1', 0.00, 1, '2017-06-17'),
(29, 17, 51, 400.00, 200.00, 0.00, '', '', '', 'Notes 2', 0.00, 1, '2017-06-17'),
(30, 17, 32, 100.00, 200.00, 0.00, '', '', '', 'Notes', 0.00, 1, '2017-06-17'),
(31, 18, 32, 200.00, 100.00, 0.00, '', '', '', 'Notes', 0.00, 1, '2017-06-20'),
(32, 18, 94, 500.00, 150.00, 0.00, '', '', '', '', 0.00, 1, '2017-06-20');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `supl_id` int(11) NOT NULL AUTO_INCREMENT,
  `supl_comp` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `supl_address` tinytext COLLATE latin1_general_ci NOT NULL,
  `supl_phone` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `supl_email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `supl_conperson` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `supl_mobile` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `supl_website` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `supl_category` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `supl_city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `supl_state` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `supl_country` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'India',
  `supl_district` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `supl_fax` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_name` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `plant_address` text COLLATE latin1_general_ci NOT NULL,
  `plant_city` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_district` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `plant_state` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_country` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'India',
  `plant_phone` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `plant_mobile` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `plant_fax` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `plant_email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `plant_conperson` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `postal_add` text COLLATE latin1_general_ci NOT NULL,
  `handling_person` int(11) NOT NULL,
  `supplier_type` enum('Supplier','Lead') COLLATE latin1_general_ci NOT NULL DEFAULT 'Supplier',
  `tin_num` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `value_rating` int(3) NOT NULL DEFAULT '0',
  `general_rating` int(3) NOT NULL DEFAULT '0',
  `general_rating_reason` text COLLATE latin1_general_ci NOT NULL,
  `value_rating_reason` text COLLATE latin1_general_ci NOT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT '0' COMMENT '0- Active, 1- in-active',
  `bank_details` text COLLATE latin1_general_ci NOT NULL,
  `vat_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `gstin_num` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `cst_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `excise_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `notes` text COLLATE latin1_general_ci NOT NULL,
  `other_information` text COLLATE latin1_general_ci NOT NULL,
  `other_products` text COLLATE latin1_general_ci NOT NULL,
  `pan_no` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `dob` date NOT NULL DEFAULT '0000-00-00',
  `updated_by` int(3) NOT NULL,
  `updated_date` date NOT NULL,
  `special_comment` text COLLATE latin1_general_ci NOT NULL,
  `horizon_supli_id` int(11) NOT NULL,
  `alligo_supli_id` int(11) NOT NULL,
  PRIMARY KEY (`supl_id`),
  KEY `handling_person` (`handling_person`),
  KEY `is_deleted` (`is_deleted`),
  KEY `updated_by` (`updated_by`,`updated_date`),
  KEY `supplier_type` (`supplier_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=484 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supl_id`, `supl_comp`, `supl_address`, `supl_phone`, `supl_email`, `supl_conperson`, `supl_mobile`, `supl_website`, `supl_category`, `supl_city`, `supl_state`, `supl_country`, `supl_district`, `supl_fax`, `plant_name`, `plant_address`, `plant_city`, `plant_district`, `plant_state`, `plant_country`, `plant_phone`, `plant_mobile`, `plant_fax`, `plant_email`, `plant_conperson`, `postal_add`, `handling_person`, `supplier_type`, `tin_num`, `value_rating`, `general_rating`, `general_rating_reason`, `value_rating_reason`, `is_deleted`, `bank_details`, `vat_no`, `gstin_num`, `cst_no`, `excise_no`, `notes`, `other_information`, `other_products`, `pan_no`, `dob`, `updated_by`, `updated_date`, `special_comment`, `horizon_supli_id`, `alligo_supli_id`) VALUES
(1, 'Supplier -1', 'Supplier Address will be here', '0222-3401991', 'supplieremail-1@gmail.com', 'Contact Name -1', '0023123521', '', '', 'Mumbai', '', '', '', '0253 - 2571577', 'Horizon Agrotech', '', 'Nasik', '', 'Maharashtra', 'India', '', '', '', '', '', 'Jaulke Village, \r\n10 th Mile, Nasik - Ozar Road, \r\nTal - Dindori, \r\nDist Nasik, \r\nMaharashtra.', 8, 'Supplier', '', 0, 0, '', '', 0, '', '27150317686 V', '27150317686 GST', '27150317686 C', '', '', '', '', '', '0000-00-00', 1, '2017-06-14', '', 1, 1),
(472, 'Supplier -2 ', 'Supplier Address will be here', '0222 819125222', 'supplieremail-2@gmail.com', 'Contact Name -2', '932119299122', '', '', 'Mumbai', '', '', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '27930176510 V', '', '27930176510 C', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(473, 'Supplier -3 ', 'Supplier Address will be here', '0253-669609233', 'supplieremail-3@gmail.com', 'Contact Name -3', '942317664033', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '27590692349 V', '', '27590692349 C', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(474, 'Supplier -4 ', 'Supplier Address will be here', '0253-660410244', 'supplieremail-4@gmail.com', 'Contact Name -4', '942156571544', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '27600410219 V', '', '27600410219 C', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(475, 'Supplier -5 ', 'Supplier Address will be here', '0253-241858855', 'supplieremail-5@gmail.com', 'Contact Name -5', '55', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '27080122512V', '', '27080122512C', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(476, 'Supplier -6 ', 'Supplier Address will be here', '0253-237240066', 'supplieremail-6@gmail.com', 'Contact Name -6', '0253-237240166', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '27660021701V', '', '27660021701C', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(477, 'Supplier -7 ', 'Supplier Address will be here', '0253-238086777', 'supplieremail-7@gmail.com', 'Contact Name -7', '992188839777', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(478, 'Supplier -8 ', 'Supplier Address will be here', '976603080288', 'supplieremail-8@gmail.com', 'Contact Name -8', '818008410888', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(479, 'Supplier -9 ', 'Supplier Address will be here', '989025509199', 'supplieremail-9@gmail.com', 'Contact Name -9', '99', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(480, 'Supplier -10 ', 'Supplier Address will be here', '94222647021010', 'supplieremail-10@gmail.com', 'Contact Name -10', '1010', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(481, 'Supplier -11 ', 'Supplier Address will be here', '94231734791111', 'supplieremail-11@gmail.com', 'Contact Name -11', '1111', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(482, 'Supplier -12 ', 'Supplier Address will be here', '922645874001212', 'supplieremail-12@gmail.com', 'Contact Name -12', '1212', '', '', 'Nashik', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0),
(483, 'Supplier -13 ', 'Supplier Address will be here', '0222-68526291313', 'supplieremail-13@gmail.com', 'Contact Name -13', '9821043211313', '', '', 'Mumbai', '', 'India', '', '', '', '', '', '', '', 'India', '', '', '', '', '', '', 0, 'Supplier', '', 0, 0, '', '', 0, '', '', 'GSTN1234', '', '', '', '', '', '', '0000-00-00', 1, '2017-03-30', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tax_structure`
--

CREATE TABLE IF NOT EXISTS `tax_structure` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_per` float(4,2) NOT NULL,
  `tax_type` varchar(15) NOT NULL,
  `status` enum('Active','In-Active') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`tax_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tax_structure`
--

INSERT INTO `tax_structure` (`tax_id`, `tax_per`, `tax_type`, `status`) VALUES
(1, 2.00, 'CST', 'In-Active'),
(2, 5.00, 'CST', 'In-Active'),
(3, 5.50, 'CST', 'In-Active'),
(4, 6.00, 'CST', 'In-Active'),
(5, 2.00, 'VAT', 'In-Active'),
(6, 5.00, 'VAT', 'In-Active'),
(7, 5.50, 'VAT', 'In-Active'),
(8, 6.00, 'VAT', 'In-Active'),
(9, 12.50, 'VAT', 'In-Active'),
(10, 13.50, 'VAT', 'In-Active'),
(11, 1.00, 'Excise', 'In-Active'),
(12, 12.50, 'Excise', 'In-Active'),
(13, 9.00, 'SGST', 'Active'),
(14, 9.00, 'CGST', 'Active'),
(15, 6.00, 'CGST', 'Active'),
(16, 6.00, 'SGST', 'Active'),
(17, 14.00, 'SGST', 'Active'),
(18, 14.00, 'CGST', 'Active'),
(20, 12.00, 'IGST', 'Active'),
(21, 18.00, 'IGST', 'Active'),
(22, 28.00, 'IGST', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(12) NOT NULL,
  `address` tinytext NOT NULL,
  `user_role` enum('Admin','Super Admin') NOT NULL DEFAULT 'Admin',
  `user_status` enum('Active','In-Active') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  KEY `user_role` (`user_role`,`user_status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `pass`, `first_name`, `last_name`, `email`, `phone_number`, `address`, `user_role`, `user_status`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'Avinash', 'Bodke', 'avinash@gmail.com', '1231321321', '', 'Super Admin', 'Active');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
